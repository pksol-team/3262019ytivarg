<?php
namespace HelpScout\model\customer;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

class ChatEntry extends CustomerEntry {

}
